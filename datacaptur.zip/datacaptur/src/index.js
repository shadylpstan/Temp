import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './css/App.css';
import Manager from './components/Manager/Manager';
import Login from './components/Login/Login';
import Opreator from './components/Opreator/Opreator';
import Adduser from './components/Admin/Adduser';
import Updateuser from './components/Admin/Updateuser';
import Deactivate from './components/Admin/Deactivate';
import "jquery";
import "popper.js/dist/umd/popper";
import "bootstrap/dist/js/bootstrap"; 
import "bootstrap/dist/css/bootstrap.css";
import Axios from 'axios';

import reportWebVitals from './reportWebVitals';



   

ReactDOM.render(

  <React.StrictMode>

    <Opreator />

  </React.StrictMode>,

  document.getElementById('root')

);

reportWebVitals();
