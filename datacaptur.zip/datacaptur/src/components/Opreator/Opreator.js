import React, {Component} from 'react';
import Accordion from 'react-bootstrap/Accordion';
import logo from './logo.jpg';
import logoexl from './exl-logo.png';
import ExamplePDFViewer from './pdf';

export default class Opreator extends Component {
state = {appTitle: "Username"};

render(){
    return(
		<div className="background">
			<nav className=" bg-nav">
				<div className="row col-12 d-flex justify-content-center text-white">
					<div className="col-md-3 col-xs-9"><img className="logo-inner" src={logo}/></div>
					<div className="col-md-8">&nbsp;</div>
					<div className="col-md-1 col-xs-3"><div class="avtar">jv</div></div>
					
				</div>
			</nav>
			<div className="row">
				<div className="col-md-10">
					<h1>Welcome {this.state.appTitle}!</h1>
				</div>
				<div className="col-md-2">
				<img className="logo-exl" src={logoexl}/>
				</div>
			</div>
      <div className="row">
        <div className=" col-md-6">&nbsp;</div>
          <div className="col-md-6">
            <a className="add-form" href="#">
            + Add form</a>
            <div class="clear"></div>
          </div>
      </div>
			<div className="row">
				<div className="col-md-6"><ExamplePDFViewer /></div>
				<div className="col-md-6 mgr-top"> 
				
				<Accordion>
  <Accordion.Item eventKey="0">
    <Accordion.Header>Information</Accordion.Header>
    <Accordion.Body>
	<div className="row">
     <div className="col-md-6">
		<label class="form-label" for="validationFormik01">First name</label>
	 <div><input name="" type="text" id="" class="form-control" value=""/></div>
	 </div>
	 <div className="col-md-6">
		<label class="form-label" for="validationFormik01">First name</label>
	 <div><input name="" type="text" id="" class="form-control" value=""/></div>
	 </div>
	
	  <div className="col-md-6">
		<label class="form-label" for="validationFormik01">First name</label>
	 <div><input name="" type="text" id="" class="form-control" value=""/></div>
	 </div>
	 <div className="col-md-6">
		<label class="form-label" for="validationFormik01">First name</label>
	 <div><input name="" type="text" id="" class="form-control" value=""/></div>
	 </div>
	 </div>
    </Accordion.Body>
  </Accordion.Item>

</Accordion></div>
			</div>
		</div>
		
		

    )
}
}
