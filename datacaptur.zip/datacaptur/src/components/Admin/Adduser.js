import React, {Component} from 'react';
import Accordion from 'react-bootstrap/Accordion';
import logo from './logo.jpg';
import logoexl from './exl-logo.png';
import { Button, Collapse } from 'react-bootstrap';


export default class Adduser extends Component {
state = {appTitle: "Username"};

render(){
    return(
		<div className="background">
			<nav className="navbar navbar-dark bg-nav">
				<div className="row col-12 d-flex justify-content-center text-white">
					<div className="col-md-3 col-xs-9"><img className="logo-inner" src={logo}/></div>
					<div className="col-md-8">&nbsp;</div>
					<div className="col-md-1 col-xs-3"><div class="avtar">jv</div></div>					
				</div>
			</nav>
			<div className="section-code">
			<div className="row">
				<div className="col-md-10">
					<h1>Welcome {this.state.appTitle}!</h1>
				</div>
				<div className="col-md-2">
				<img className="logo-exl" src={logoexl}/>
				</div>
			</div>
			<div className="row">
				<div className="row ">	
					<div className="col-md-3">
						<div className="col-md-12">
							
								<Button className="col-md-12 btn-admin" variant="outline-success">Add User</Button>
								<Button className="col-md-12 btn-admin" variant="outline-warning">Update User</Button>
								<Button className="col-md-12 btn-admin" variant="outline-dark">Deactivate user</Button>
							
						</div>
					</div>
					<div className="col-md-9 white-bg user-details">
					<h2>Add User</h2>
						<div className="row">
     <div className="form-group col-md-6">
		<label className="form-label" for="validationFormik01">Name </label>
	 <div><input name="" type="text" id="" className="form-control" value=""/></div>
	 </div>
	 <div className="form-group col-md-6">
		<label className="form-label" for="validationFormik01">Userid</label>
	 <div><input name="" type="text" id="" className="form-control" value=""/></div>
	 </div>
	 
	  <div className="form-group col-md-6">
		<label className="form-label" for="validationFormik01">Email address</label>
	 <div><input name="" type="text" id="" className="form-control" value=""/></div>
	 </div>
	 <div className="form-group col-md-6">
		<label className="form-label" for="validationFormik01">Contact number</label>
	 <div><input name="" type="text" id="" className="form-control" value=""/></div>
	 </div>
	 
	  <div className="form-group col-md-6">
		<label className="form-label" for="validationFormik01">Password </label>
	 <div><input name="" type="text" id="" className="form-control" value=""/></div>
	 </div>
	 <div className=" form-group col-md-6">
		<label className="form-label" for="validationFormik01">Field/Key</label>
	 <div><input name="" type="text" id="" className="form-control" value=""/></div>
	 </div>
	  <div className=" form-group col-md-12">
	 <a href=""  className="form-group  btn btn-primary  sub-button">Submit</a>
	 </div>
	 </div>
					</div>
					<div class="clear"></div>
				</div>
			</div>
</div>			
		</div>
		
		

    )
}
}
