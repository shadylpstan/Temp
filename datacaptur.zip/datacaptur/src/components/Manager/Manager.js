import React, {useState} from 'react';
import { Button, Collapse } from 'react-bootstrap';
import Accordion from 'react-bootstrap/Accordion';


function Manager() {
	const [open, setOpen] = useState(false);

    return(
		<div class="background">
			<nav class="navbar navbar-dark bg-nav">
				<div className="row col-12 d-flex justify-content-center text-white">
				<div className="col-md-3">Logo</div>
				<div className="col-md-9">&nbsp;</div>
				</div>
			</nav>
			<div className="section-code">
			<h1>Welcome username!</h1>
			<div className="col-md-12">
				<div className="row">
					<div className="col-md-3 d-flex"><div className="bg-primary text-black spacer font-box">Not Started</div></div>
					<div className="col-md-3 d-flex"><div className="bg-warning text-black spacer font-box ">Processing</div></div>
					<div className="col-md-3 d-flex"><div className="bg-secondary text-black spacer font-box">Review Claims</div></div>
					<div className="col-md-3 d-flex"><div className="bg-danger text-black spacer font-box">Error Claims</div></div>			
				</div>
			</div>
			<div className="col-md-12 row d-flex">				
					<div className="white-bg">					
						<div className="row form-group">
							<div className=" col-md-6  d-flex">
								<div className="col-md-3 d-flex">
									<h2>Assign to</h2>
								</div>
								<div className="col-md-6 d-flex">
									<div className="col-md-12">								
									<select class="form-select" id="disabledSelect">
									<option>Select Opreator</option>
									</select>
									</div>
								</div>
							</div>
							<div className="offset-md-4 col-md-2  d-flex">
								<a href="" className="form-control float-right btn btn-primary">Assign</a>
							</div>
						</div>
						<div className="">
							<Button	onClick={() => setOpen(!open)} 	aria-controls="Filter by"   className="filter"	aria-expanded={open}>Filter by	</Button>
							<Collapse in={open}>
								<div id="Filter by" className="col-md-12">
								<table className="table form-group">
									<tr>
										<td> <input type="" className="form-control" placeholder="Filter by Case ID" /></td>
										<td><input type="" className="form-control" placeholder="Filter by Creation Date" /></td>
										<td><input type="" className="form-control" placeholder="Filter by Ageing" /></td>
										<td><input type="" className="form-control" placeholder="Filter by Status" /></td>
										<td><input type="" className="form-control" placeholder="Filter by LOB" /></td>
										<td><input type="" className="form-control" placeholder="Filter by Picked By" /></td>
									</tr>
								</table>
								</div>
							</Collapse>
						</div>
										
						<table className="table table-bordered">
						<tr>
						<th>Case ID</th>
							<th>Creation Date</th>
							<th>Ageing</th>
							<th>Status</th>
							<th>LOB</th>
							<th>Picked By</th>
						</tr>
						
						<tr>
						<td>Case ID</td>
							<td>Creation Date</td>
							<td>Ageing</td>
							<td>Status</td>
							<td>LOB</td>
							<td>Picked By</td>
						</tr>
						</table>
						
					</div>
				
			</div>
			</div>
		</div>
    )
}
export default Manager;