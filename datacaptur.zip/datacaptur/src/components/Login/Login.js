import React, {Component} from 'react';

 function Login() {
  return (
    <div className="App bg_image  py-9"  >
		<div className="maincontainer">
        <div className="container-fluid">
            <div className="row no-gutter">  
                <div className="offset-md-4 col-md-4 bg-light login-form">
                    <div className="login  d-flex align-items-center">
                        <div className="col-md-12">
                            <div className="row">
                                <div className="col-md-12 col-lg-12 col-xl-12 ">
                                   <div  className="logo"></div>
                                    <form>
                                        <div className="form-group mb-12 py-2">
                                            <input id="inputUsername" type="username" placeholder="User Name" required="" autofocus="" className="input-bg form-control rounded-pill border-0 shadow-sm px-4" />
                                        </div>
                                        <div className="form-group mb-12 py-2">
                                            <input id="inputPassword" type="password" placeholder="Password" required="" className="input-bg form-control rounded-pill border-0 shadow-sm px-4 text-primary" />
                                        </div>
                                        <div className="custom-control custom-checkbox mb-12 py-2">
                                            <a href="">Forgot password</a>&nbsp;&nbsp;&nbsp;&nbsp; <a href="">Reset password</a>
                                        </div>

                                        <button type="submit"  className="btn btn-primary btn-block text-uppercase mb-2 rounded-pill shadow-sm">Login</button>
                                        
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
      </div>
    </div>
  );
} 

export default Login;
